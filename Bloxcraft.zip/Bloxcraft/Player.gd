extends CharacterBody3D

const Items = preload("res://items.gd")
const Saves = preload("res://saves.gd")

const SPEED = 5.0
const FLY_SPEED = 12.0
const JUMP = 5.0
const REACH = 5.0
const SLOTS = 36          # slots 0-8 are the hotbar
const ARMOR_START = 36    # 36 helmet, 37 chestplate, 38 leggings, 39 boots
const OFFHAND = 40
const HOTBAR = 9
const WORLD_HEIGHT = 64
const SPAWN = Vector3(8, 70, 8)
const SETTINGS_PATH = "user://settings.cfg"
const MAX_HEALTH = 20.0
const MAX_HUNGER = 20
const THIRD_PERSON_DISTANCE = 4.0

var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")
var sensitivity = 0.003
var pitch = 0.0
var flashlight
var creative = false
var flying = false
var last_space_time = -1.0

# Each slot is null (empty) or [item_id, count] (tools and armor: [item_id, 1, durability_left])
var inventory = []
var armor = [null, null, null, null]
var offhand = null
var selected_slot = 0
var creative_target = 0   # slot that creative-menu clicks fill
var inventory_open = false
var held = null           # the stack you're carrying with the mouse
var recipes = Items.build_recipes()

# Health and hunger
var health = MAX_HEALTH
var hunger = MAX_HUNGER
var exhaustion = 0.0
var regen_timer = 0.0
var starve_timer = 0.0
var dead = false
var air_peak_y = 0.0
var fall_ready = false    # no fall damage until you've landed once

# Mining (survival: hold the left mouse button)
var mine_pos = Vector3i(-99999, 0, 0)
var mine_time = 0.0
var mine_ratio = 0.0      # 0 to 1, shown by the HUD

# Camera and body model
var third_person = false
var model
var head_mesh
var armor_parts = [[], [], [], []]

# Beta test options (set from the Admin panel)
var god_mode = false
var admin_fly = false
var instant_mine = false
var speed_mult = 1.0

@onready var head = $Head
@onready var world = get_node("../World")
@onready var hud = get_node("../HUD")

func _ready():
	Saves.ensure_current()
	global_position = SPAWN
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	load_settings()
	flashlight = SpotLight3D.new()
	flashlight.spot_range = 40.0
	flashlight.spot_angle = 30.0
	flashlight.light_energy = 4.0
	flashlight.spot_attenuation = 0.8
	$Head/Camera3D.add_child(flashlight)
	build_model()
	for i in SLOTS:
		inventory.append(null)
	if not load_player_data():
		# Brand new world: starter items so you can test things right away
		inventory[0] = [4, 32]                  # planks
		inventory[1] = [1, 32]                  # stone
		inventory[2] = [5, 16]                  # logs
		inventory[3] = Items.new_stack(200, 1)  # wooden pickaxe
	update_model()

# ---------- Settings and saving ----------

func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		sensitivity = cfg.get_value("settings", "sensitivity", 0.003)

# Returns true if this world already had a saved player
func load_player_data():
	var cfg = ConfigFile.new()
	if cfg.load(Saves.info_path(Saves.current_id)) != OK:
		return false
	creative = cfg.get_value("world", "creative", false)
	if not cfg.has_section_key("player", "position"):
		return false
	global_position = cfg.get_value("player", "position", SPAWN)
	rotation.y = cfg.get_value("player", "yaw", 0.0)
	pitch = cfg.get_value("player", "pitch", 0.0)
	head.rotation = Vector3(pitch, 0, 0)
	selected_slot = clampi(cfg.get_value("player", "selected_slot", 0), 0, HOTBAR - 1)
	creative_target = selected_slot
	var saved_inv = cfg.get_value("player", "inventory", [])
	for i in mini(saved_inv.size(), SLOTS):
		inventory[i] = saved_inv[i]
	var saved_armor = cfg.get_value("player", "armor", [])
	for i in mini(saved_armor.size(), 4):
		armor[i] = saved_armor[i]
	offhand = cfg.get_value("player", "offhand", null)
	health = float(cfg.get_value("player", "health", MAX_HEALTH))
	if health <= 0.0:
		health = MAX_HEALTH
	hunger = int(cfg.get_value("player", "hunger", MAX_HUNGER))
	return true

func save_player():
	var path = Saves.info_path(Saves.current_id)
	var cfg = ConfigFile.new()
	cfg.load(path)   # keeps the world's name and seed
	cfg.set_value("world", "creative", creative)
	cfg.set_value("world", "last_played", int(Time.get_unix_time_from_system()))
	cfg.set_value("player", "position", global_position)
	cfg.set_value("player", "yaw", rotation.y)
	cfg.set_value("player", "pitch", pitch)
	cfg.set_value("player", "selected_slot", selected_slot)
	cfg.set_value("player", "inventory", inventory)
	cfg.set_value("player", "armor", armor)
	cfg.set_value("player", "offhand", offhand)
	cfg.set_value("player", "health", health)
	cfg.set_value("player", "hunger", hunger)
	cfg.save(path)

func set_creative(value):
	creative = value
	if not can_fly():
		flying = false
	hud.refresh()

func can_fly():
	return creative or admin_fly

func set_admin_fly(value):
	admin_fly = value
	if not can_fly():
		flying = false

# ---------- Body model (visible in third person) ----------

func make_box(parent, pos, size, color):
	var m = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = size
	m.mesh = box
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	m.material_override = mat
	m.position = pos
	parent.add_child(m)
	return m

func build_model():
	model = Node3D.new()
	add_child(model)
	var skin = Color(0.85, 0.65, 0.5)
	var shirt = Color(0.2, 0.45, 0.8)
	var pants = Color(0.25, 0.25, 0.5)
	make_box(model, Vector3(0, 0.1, 0), Vector3(0.5, 0.7, 0.25), shirt)
	make_box(model, Vector3(-0.36, 0.1, 0), Vector3(0.2, 0.7, 0.2), skin)
	make_box(model, Vector3(0.36, 0.1, 0), Vector3(0.2, 0.7, 0.2), skin)
	make_box(model, Vector3(-0.13, -0.575, 0), Vector3(0.22, 0.65, 0.22), pants)
	make_box(model, Vector3(0.13, -0.575, 0), Vector3(0.22, 0.65, 0.22), pants)
	head_mesh = make_box(head, Vector3(0, -0.05, 0), Vector3(0.5, 0.5, 0.5), skin)
	# Armor pieces drawn over the body (colored by material)
	armor_parts[0].append(make_box(head, Vector3(0, -0.05, 0), Vector3(0.58, 0.58, 0.58), Color.WHITE))
	armor_parts[1].append(make_box(model, Vector3(0, 0.1, 0), Vector3(0.58, 0.78, 0.33), Color.WHITE))
	armor_parts[1].append(make_box(model, Vector3(-0.36, 0.1, 0), Vector3(0.28, 0.78, 0.28), Color.WHITE))
	armor_parts[1].append(make_box(model, Vector3(0.36, 0.1, 0), Vector3(0.28, 0.78, 0.28), Color.WHITE))
	armor_parts[2].append(make_box(model, Vector3(-0.13, -0.5, 0), Vector3(0.3, 0.45, 0.3), Color.WHITE))
	armor_parts[2].append(make_box(model, Vector3(0.13, -0.5, 0), Vector3(0.3, 0.45, 0.3), Color.WHITE))
	armor_parts[3].append(make_box(model, Vector3(-0.13, -0.8, 0), Vector3(0.3, 0.2, 0.3), Color.WHITE))
	armor_parts[3].append(make_box(model, Vector3(0.13, -0.8, 0), Vector3(0.3, 0.2, 0.3), Color.WHITE))

func update_model():
	model.visible = third_person
	head_mesh.visible = third_person
	for t in 4:
		var item = armor[t]
		for part in armor_parts[t]:
			part.visible = third_person and item != null
			if item != null:
				part.material_override.albedo_color = Items.ARMOR_COLORS[Items.armor_tier(item[0])]

# First person: camera at the eyes. Third person: pulled back, stopping at walls.
func update_camera():
	var cam = $Head/Camera3D
	if not third_person:
		cam.position = Vector3.ZERO
		return
	var from = head.global_position
	var to = from + head.global_transform.basis.z * THIRD_PERSON_DISTANCE
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [get_rid()]
	var hit = get_world_3d().direct_space_state.intersect_ray(query)
	var dist = THIRD_PERSON_DISTANCE
	if not hit.is_empty():
		dist = maxf(from.distance_to(hit.position) - 0.3, 0.2)
	cam.position = Vector3(0, 0, dist)

# ---------- Input ----------

func select_slot(i):
	selected_slot = i
	creative_target = i
	hud.refresh()

func _unhandled_input(event):
	if dead:
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
		set_inventory(not inventory_open)
		return
	if inventory_open:
		return

	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotation.y -= event.relative.x * sensitivity
		pitch = clamp(pitch - event.relative.y * sensitivity, deg_to_rad(-89), deg_to_rad(89))
		head.rotation = Vector3(pitch, 0, 0)
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode >= KEY_1 and event.keycode <= KEY_9:
			select_slot(event.keycode - KEY_1)
		elif event.keycode == KEY_F:
			flashlight.visible = not flashlight.visible
		elif event.keycode == KEY_F5:
			third_person = not third_person
			update_model()
		elif event.keycode == KEY_X:
			swap_offhand()
		elif event.keycode == KEY_SPACE and can_fly():
			# Double-tap Space to start or stop flying
			var now = Time.get_ticks_msec() / 1000.0
			if now - last_space_time < 0.3:
				flying = not flying
				velocity.y = 0
			last_space_time = now
	if event is InputEventMouseButton and event.pressed:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		elif event.button_index == MOUSE_BUTTON_LEFT:
			if creative:
				mine()   # creative breaks blocks instantly. Survival holds the button instead.
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			if not use_hand(false):
				use_hand(true)
		elif event.button_index == MOUSE_BUTTON_MIDDLE and creative:
			pick_block()
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			select_slot((selected_slot + HOTBAR - 1) % HOTBAR)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			select_slot((selected_slot + 1) % HOTBAR)

func _physics_process(delta):
	if dead:
		return
	# Wait in the air until the ground under you has loaded
	if not world.is_loaded_at(global_position):
		return
	# Safety net if you ever fall out of the world
	if global_position.y < -30:
		teleport(Vector3(global_position.x, SPAWN.y, global_position.z))

	update_mining(delta)

	var flying_now = flying and can_fly()
	if flying_now:
		var vy = 0.0
		if not inventory_open:
			if Input.is_physical_key_pressed(KEY_SPACE):
				vy += 1.0
			if Input.is_physical_key_pressed(KEY_SHIFT):
				vy -= 1.0
		velocity.y = vy * FLY_SPEED * 0.6 * speed_mult
		if vy < 0 and is_on_floor():
			flying = false   # landing stops the flight
	else:
		if not is_on_floor():
			velocity.y -= gravity * delta
		if Input.is_physical_key_pressed(KEY_SPACE) and is_on_floor() and not inventory_open:
			velocity.y = JUMP

	var input_dir = Vector2.ZERO
	if not inventory_open:
		if Input.is_physical_key_pressed(KEY_W):
			input_dir.y -= 1
		if Input.is_physical_key_pressed(KEY_S):
			input_dir.y += 1
		if Input.is_physical_key_pressed(KEY_A):
			input_dir.x -= 1
		if Input.is_physical_key_pressed(KEY_D):
			input_dir.x += 1

	var speed = (FLY_SPEED if flying_now else SPEED) * speed_mult
	var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	move_and_slide()

	update_falling(flying_now)
	update_survival(delta)
	update_camera()

func teleport(pos):
	global_position = pos
	velocity = Vector3.ZERO
	fall_ready = false
	air_peak_y = pos.y

# ---------- Health and hunger ----------

func update_falling(flying_now):
	if creative or flying_now or god_mode:
		air_peak_y = global_position.y
		return
	if is_on_floor():
		if fall_ready:
			var fell = air_peak_y - global_position.y
			if fell > 3.0:
				take_damage(floorf(fell - 3.0), "fall")
		fall_ready = true
		air_peak_y = global_position.y
	else:
		air_peak_y = maxf(air_peak_y, global_position.y)

func update_survival(delta):
	if creative or dead:
		return
	# Hunger drains slowly, faster when walking
	exhaustion += delta * 0.005
	if is_on_floor() and Vector2(velocity.x, velocity.z).length() > 0.1:
		exhaustion += delta * 0.025
	if exhaustion >= 1.0:
		exhaustion -= 1.0
		hunger = maxi(hunger - 1, 0)
		hud.refresh_status()
	# Heal when well fed, starve when empty
	if hunger >= 18 and health < MAX_HEALTH:
		regen_timer += delta
		if regen_timer >= 4.0:
			regen_timer = 0.0
			heal(1.0)
			exhaustion += 0.3
	elif hunger == 0:
		starve_timer += delta
		if starve_timer >= 4.0:
			starve_timer = 0.0
			take_damage(1.0, "starve")
	else:
		regen_timer = 0.0
		starve_timer = 0.0

func heal(amount):
	health = minf(health + amount, MAX_HEALTH)
	hud.refresh_status()

# kind: "attack" is reduced by armor. "fall" and "starve" ignore armor.
func take_damage(amount, kind = "attack"):
	if creative or god_mode or dead or amount <= 0:
		return
	var dmg = amount
	if kind == "attack":
		dmg = amount * (1.0 - minf(armor_points() * 0.04, 0.8))
		wear_armor()
	health = maxf(health - dmg, 0.0)
	hud.flash_damage()
	hud.refresh_status()
	if health <= 0.0:
		die()

func armor_points():
	var total = 0
	for a in armor:
		if a != null:
			total += Items.armor_points(a[0])
	return total

# Every worn piece loses 1 durability when armor absorbs a hit
func wear_armor():
	for i in 4:
		var a = armor[i]
		if a == null:
			continue
		if a.size() < 3:
			a.append(Items.max_durability(a[0]))
		a[2] -= 1
		if a[2] <= 0:
			armor[i] = null
	update_model()
	hud.refresh()

func die():
	dead = true
	reset_mining()
	if held != null:
		add_stack(held)
		held = null
	inventory_open = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	hud.refresh()

func respawn():
	health = MAX_HEALTH
	hunger = MAX_HUNGER
	exhaustion = 0.0
	regen_timer = 0.0
	starve_timer = 0.0
	dead = false
	flying = false
	teleport(SPAWN)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	hud.refresh()

# ---------- Admin panel helpers ----------

func heal_and_feed():
	health = MAX_HEALTH
	hunger = MAX_HUNGER
	hud.refresh_status()

func give_kit():
	for k in 4:
		add_stack(Items.new_stack(250 + k, 1))   # diamond tools
	for k in 4:
		add_stack(Items.new_stack(330 + k, 1))   # diamond armor
	add_item(Items.APPLE, 16)
	hud.refresh()

# ---------- Inventory ----------

func get_slot(i):
	if i < SLOTS:
		return inventory[i]
	if i < OFFHAND:
		return armor[i - ARMOR_START]
	return offhand

func set_slot(i, value):
	if i < SLOTS:
		inventory[i] = value
	elif i < OFFHAND:
		armor[i - ARMOR_START] = value
	else:
		offhand = value

# Armor slots only accept the matching armor piece
func can_place_in_slot(i, stack):
	if i >= ARMOR_START and i < OFFHAND:
		return stack == null or (Items.is_armor_item(stack[0]) and Items.armor_type(stack[0]) == i - ARMOR_START)
	return true

func swap_offhand():
	var tmp = inventory[selected_slot]
	inventory[selected_slot] = offhand
	offhand = tmp
	hud.refresh()

func set_inventory(open):
	inventory_open = open
	if not open and held != null:
		add_stack(held)   # put the carried stack back
		held = null
	if open:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	hud.refresh()

# Adds items to the inventory. Returns how many didn't fit.
func add_item(id, amount = 1):
	var limit = Items.max_stack(id)
	for slot in inventory:
		if slot != null and slot[0] == id and slot[1] < limit:
			var put = min(limit - slot[1], amount)
			slot[1] += put
			amount -= put
			if amount == 0:
				return 0
	for i in SLOTS:
		if inventory[i] == null:
			var put = min(limit, amount)
			inventory[i] = Items.new_stack(id, put)
			amount -= put
			if amount == 0:
				return 0
	return amount

# Puts a whole stack (keeping its durability) into the first free slot
func add_stack(stack):
	if stack.size() > 2:
		for i in SLOTS:
			if inventory[i] == null:
				inventory[i] = stack
				return true
		return false
	return add_item(stack[0], stack[1]) == 0

# Survival: left-click on a slot in the inventory screen
func click_slot(i):
	var slot = get_slot(i)
	if held != null and not can_place_in_slot(i, held):
		return
	if held == null:
		held = slot
		set_slot(i, null)
	elif slot == null:
		set_slot(i, held)
		held = null
	elif slot[0] == held[0] and Items.max_stack(slot[0]) > 1:
		var limit = Items.max_stack(slot[0])
		var total = slot[1] + held[1]
		if total <= limit:
			slot[1] = total
			held = null
		else:
			slot[1] = limit
			held[1] = total - limit
	else:
		set_slot(i, held)
		held = slot
	update_model()
	hud.refresh()

# Creative: click a block or item in the palette to put it in the chosen slot
func pick_creative(id):
	var stack = Items.new_stack(id, 1)
	if not can_place_in_slot(creative_target, stack):
		return
	set_slot(creative_target, stack)
	update_model()
	hud.refresh()

# Creative: left-click chooses a slot to fill, right-click also clears it
func click_creative_slot(i, button):
	if button == MOUSE_BUTTON_RIGHT:
		set_slot(i, null)
		update_model()
	creative_target = i
	if i < HOTBAR:
		selected_slot = i
	hud.refresh()

# ---------- Crafting ----------

func count_item(id):
	var n = 0
	for slot in inventory:
		if slot != null and slot[0] == id:
			n += slot[1]
	return n

func can_craft(recipe):
	for id in recipe["in"]:
		if count_item(id) < recipe["in"][id]:
			return false
	return true

func remove_items(id, amount):
	for i in SLOTS:
		var slot = inventory[i]
		if slot != null and slot[0] == id:
			var take = min(slot[1], amount)
			slot[1] -= take
			amount -= take
			if slot[1] <= 0:
				inventory[i] = null
			if amount <= 0:
				return

func craft(index):
	var recipe = recipes[index]
	if not can_craft(recipe):
		return
	for id in recipe["in"]:
		remove_items(id, recipe["in"][id])
	add_item(recipe["out"], recipe["count"])
	hud.refresh()

# ---------- Mining and placing ----------

func get_target():
	var cam = $Head/Camera3D
	var from = cam.global_position
	var to = from - cam.global_transform.basis.z * (REACH + cam.position.z)
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [get_rid()]
	return get_world_3d().direct_space_state.intersect_ray(query)

func reset_mining():
	mine_pos = Vector3i(-99999, 0, 0)
	mine_time = 0.0
	mine_ratio = 0.0

# Returns [mining speed, pickaxe tier] for the tool in your hand
func mining_info(block_id):
	var speed = 1.0
	var tier = -1
	var item = inventory[selected_slot]
	if item != null and Items.is_tool_item(item[0]):
		var t = Items.tool_tier(item[0])
		var kind = Items.tool_type(item[0])
		if kind == 0:
			tier = Items.TIER_MINING[t]
		if kind == Items.BEST_TOOL.get(block_id, -1):
			speed = Items.TIER_SPEED[t]
	return [speed, tier]

# The held tool loses 1 durability per block broken
func damage_tool():
	var item = inventory[selected_slot]
	if item == null or not Items.is_tool_item(item[0]):
		return
	if item.size() < 3:
		item.append(Items.max_durability(item[0]))
	item[2] -= 1
	if item[2] <= 0:
		inventory[selected_slot] = null

# Survival: hold the left mouse button to break the block you're looking at
func update_mining(delta):
	var holding = not creative and not inventory_open \
		and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED \
		and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	if not holding:
		reset_mining()
		return
	var hit = get_target()
	if hit.is_empty():
		reset_mining()
		return
	var p = hit.position - hit.normal * 0.01
	var pos = Vector3i(floori(p.x), floori(p.y), floori(p.z))
	var id = world.get_block(pos.x, pos.y, pos.z)
	if id == 0 or id == 7:   # air or bedrock
		reset_mining()
		return
	if pos != mine_pos:
		mine_pos = pos
		mine_time = 0.0
	var info = mining_info(id)
	var needed = Items.HARDNESS.get(id, 3.0)
	if instant_mine:
		needed = 0.01
	mine_time += delta * info[0]
	mine_ratio = clamp(mine_time / needed, 0.0, 1.0)
	if mine_time >= needed:
		world.set_block(pos.x, pos.y, pos.z, 0)
		var drop = Items.drop_for(id, info[1])
		if drop != 0:
			add_item(drop)
		if id == 8 and randf() < 0.15:
			add_item(Items.APPLE)   # leaves sometimes drop an apple
		damage_tool()
		exhaustion += 0.05
		hud.refresh()
		reset_mining()

# Creative: instant break, nothing added to the inventory
func mine():
	var hit = get_target()
	if hit.is_empty():
		return
	var p = hit.position - hit.normal * 0.01
	var bx = floori(p.x)
	var by = floori(p.y)
	var bz = floori(p.z)
	var id = world.get_block(bx, by, bz)
	if id == 0 or id == 7:
		return
	world.set_block(bx, by, bz, id * 0)

func pick_block():
	var hit = get_target()
	if hit.is_empty():
		return
	var p = hit.position - hit.normal * 0.01
	var id = world.get_block(floori(p.x), floori(p.y), floori(p.z))
	if id == 0:
		return
	inventory[selected_slot] = Items.new_stack(id, 1)
	hud.refresh()

# Right-click with the main hand or the offhand: eat food, or place a block.
# Returns true if something happened.
func use_hand(is_offhand):
	var item = offhand if is_offhand else inventory[selected_slot]
	if item == null:
		return false
	var id = item[0]
	if Items.is_food(id):
		if creative or hunger >= MAX_HUNGER:
			return false
		hunger = mini(MAX_HUNGER, hunger + Items.FOOD[id])
		item[1] -= 1
		if item[1] <= 0:
			if is_offhand:
				offhand = null
			else:
				inventory[selected_slot] = null
		hud.refresh()
		return true
	if id < 100:
		return place_block(item, is_offhand)
	return false

func place_block(item, is_offhand):
	var hit = get_target()
	if hit.is_empty():
		return false
	var p = hit.position + hit.normal * 0.01
	var bx = floori(p.x)
	var by = floori(p.y)
	var bz = floori(p.z)
	if by < 0 or by >= WORLD_HEIGHT:
		return false
	if not world.is_loaded_at(Vector3(bx, 0, bz)):
		return false
	# Don't place a block inside yourself
	var block_box = AABB(Vector3(bx, by, bz), Vector3.ONE)
	var player_box = AABB(global_position - Vector3(0.3, 0.9, 0.3), Vector3(0.6, 1.8, 0.6))
	if block_box.intersects(player_box):
		return false
	world.set_block(bx, by, bz, item[0])
	if not creative:
		item[1] -= 1
		if item[1] <= 0:
			if is_offhand:
				offhand = null
			else:
				inventory[selected_slot] = null
	hud.refresh()
	return true
