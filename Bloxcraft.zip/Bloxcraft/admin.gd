extends CanvasLayer
# Beta test tools. Press F1 in the game, or use the button in the pause menu.

var xray_check
var god_check
var fly_check
var instant_check
var speed_slider
var speed_label
var status_label

@onready var player = get_node("../Player")
@onready var world = get_node("../World")
@onready var pause_menu = get_node("../Pause")

func _ready():
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS   # keep working while the game is paused
	visible = false

	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center = CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel = PanelContainer.new()
	center.add_child(panel)
	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	panel.add_child(box)

	var title = Label.new()
	title.text = "Admin Panel (Beta)"
	title.add_theme_font_size_override("font_size", 36)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	var hint = Label.new()
	hint.text = "Test tools. Press F1 or Esc to close."
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(hint)

	xray_check = add_check(box, "X-Ray (see through blocks, ores stay solid)")
	god_check = add_check(box, "God mode (no damage)")
	fly_check = add_check(box, "Fly anywhere (double-tap Space)")
	instant_check = add_check(box, "Instant mining")
	xray_check.toggled.connect(func(on): world.set_xray(on))
	god_check.toggled.connect(func(on): player.god_mode = on)
	fly_check.toggled.connect(func(on): player.set_admin_fly(on))
	instant_check.toggled.connect(func(on): player.instant_mine = on)

	speed_label = Label.new()
	speed_label.add_theme_font_size_override("font_size", 20)
	box.add_child(speed_label)
	speed_slider = HSlider.new()
	speed_slider.min_value = 1.0
	speed_slider.max_value = 5.0
	speed_slider.step = 0.5
	speed_slider.custom_minimum_size = Vector2(420, 24)
	speed_slider.value_changed.connect(_on_speed_changed)
	box.add_child(speed_slider)

	add_action(box, "Heal and Feed", _on_heal)
	add_action(box, "Take 4 Damage (tests armor)", _on_damage)
	add_action(box, "Set Hunger to 4", _on_hunger)
	add_action(box, "Give Diamond Kit", _on_kit)
	add_action(box, "Teleport to Spawn", _on_teleport)

	status_label = Label.new()
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(status_label)

	add_action(box, "Close", close_panel)

func add_check(parent, text):
	var c = CheckButton.new()
	c.text = text
	c.add_theme_font_size_override("font_size", 20)
	parent.add_child(c)
	return c

func add_action(parent, text, callback):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(420, 44)
	b.add_theme_font_size_override("font_size", 20)
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func update_speed_label():
	speed_label.text = "Speed multiplier: x" + str(speed_slider.value)

func _on_speed_changed(value):
	player.speed_mult = value
	update_speed_label()

func _on_heal():
	player.heal_and_feed()
	status_label.text = "Health and hunger refilled."

func _on_damage():
	player.take_damage(4.0, "attack")
	status_label.text = "Took 4 attack damage (armor applies)."

func _on_hunger():
	player.hunger = 4
	player.hud.refresh_status()
	status_label.text = "Hunger set to 4."

func _on_kit():
	player.give_kit()
	status_label.text = "Diamond tools, armor and apples added."

func _on_teleport():
	player.teleport(player.SPAWN)
	status_label.text = "Teleported to spawn."

func _unhandled_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F1:
			if visible:
				close_panel()
			elif not pause_menu.visible and not player.inventory_open and not player.dead:
				open_panel()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_ESCAPE and visible:
			close_panel()
			get_viewport().set_input_as_handled()

func open_panel():
	xray_check.set_pressed_no_signal(world.xray)
	god_check.set_pressed_no_signal(player.god_mode)
	fly_check.set_pressed_no_signal(player.admin_fly)
	instant_check.set_pressed_no_signal(player.instant_mine)
	speed_slider.set_value_no_signal(player.speed_mult)
	update_speed_label()
	status_label.text = ""
	visible = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func close_panel():
	visible = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
