extends MeshInstance3D

const SIZE = 16
const HEIGHT = 64
const TILES_PER_ROW = 4

# Block IDs: 0 air, 1 stone, 2 dirt, 3 grass, 4 planks, 5 log, 6 andesite, 7 bedrock, 8 leaves,
# 9 copper ore, 10 iron ore, 11 gold ore, 12 diamond ore, 13 emerald ore
# Each block: [top tile, bottom tile, side tile] in atlas.png
const BLOCK_TILES = {
	1: [3, 3, 3],
	2: [2, 2, 2],
	3: [0, 2, 1],
	4: [4, 4, 4],
	5: [6, 6, 5],
	6: [7, 7, 7],
	7: [8, 8, 8],
	8: [9, 9, 9],
	9: [10, 10, 10],
	10: [11, 11, 11],
	11: [12, 12, 12],
	12: [13, 13, 13],
	13: [14, 14, 14],
}

const FACES = [
	{"dir": Vector3i(0, 1, 0), "verts": [Vector3(0,1,0), Vector3(1,1,0), Vector3(1,1,1), Vector3(0,1,1)]},   # top
	{"dir": Vector3i(0, -1, 0), "verts": [Vector3(0,0,1), Vector3(1,0,1), Vector3(1,0,0), Vector3(0,0,0)]},  # bottom
	{"dir": Vector3i(0, 0, 1), "verts": [Vector3(0,1,1), Vector3(1,1,1), Vector3(1,0,1), Vector3(0,0,1)]},   # front
	{"dir": Vector3i(0, 0, -1), "verts": [Vector3(1,1,0), Vector3(0,1,0), Vector3(0,0,0), Vector3(1,0,0)]},  # back
	{"dir": Vector3i(1, 0, 0), "verts": [Vector3(1,1,1), Vector3(1,1,0), Vector3(1,0,0), Vector3(1,0,1)]},   # right
	{"dir": Vector3i(-1, 0, 0), "verts": [Vector3(0,1,0), Vector3(0,1,1), Vector3(0,0,1), Vector3(0,0,0)]},  # left
]

# These are filled in by world.gd before the chunk is added
var world
var cx = 0
var cz = 0

var blocks = PackedByteArray()
var top = 0            # highest non-air block, so we skip empty air when building
var dirty = false      # true when the player edited this chunk since it was last saved

func _ready():
	var data = world.take_saved(Vector2i(cx, cz))
	if data != null and data["blocks"].size() == SIZE * SIZE * HEIGHT:
		blocks = data["blocks"]
		top = data["top"]
	else:
		generate_data()
	apply_xray()
	build_mesh()

# Swaps in the see-through material when X-Ray is on (Admin panel)
func apply_xray():
	material_override = world.xray_material if world.xray else null

func index(x, y, z):
	return x + z * SIZE + y * SIZE * SIZE

func get_block(x, y, z):
	if x < 0 or x >= SIZE or z < 0 or z >= SIZE or y < 0 or y >= HEIGHT:
		return 0
	return blocks[index(x, y, z)]

func set_block(x, y, z, id):
	if x < 0 or x >= SIZE or z < 0 or z >= SIZE or y < 0 or y >= HEIGHT:
		return
	# Bedrock can't be broken
	if id == 0 and blocks[index(x, y, z)] == 7:
		return
	blocks[index(x, y, z)] = id
	dirty = true
	if id != 0:
		top = maxi(top, y)
	build_mesh()

func generate_data():
	blocks.resize(SIZE * SIZE * HEIGHT)
	blocks.fill(0)
	var x0 = cx * SIZE
	var z0 = cz * SIZE
	for x in SIZE:
		for z in SIZE:
			var wx = x0 + x
			var wz = z0 + z
			var h = world.terrain_height(wx, wz)
			for y in range(0, h + 1):
				var id = world.terrain_block(wx, y, wz, h)
				if id != 0:
					blocks[index(x, y, z)] = id
			top = maxi(top, h)
	add_trees()

# Trees are placed by world position, so a tree that crosses a chunk border
# gets built correctly by both chunks.
func add_trees():
	var x0 = cx * SIZE
	var z0 = cz * SIZE
	for wx in range(x0 - 2, x0 + SIZE + 2):
		for wz in range(z0 - 2, z0 + SIZE + 2):
			if not world.is_tree_origin(wx, wz):
				continue
			var base = world.terrain_height(wx, wz)
			var th = world.tree_height(wx, wz)
			for dy in range(th - 1, th + 3):
				var r = 2 if dy <= th else 1
				for dx in range(-r, r + 1):
					for dz in range(-r, r + 1):
						if abs(dx) == r and abs(dz) == r:
							continue
						put(wx + dx - x0, base + dy, wz + dz - z0, 8, false)
			for ty in range(1, th + 1):
				put(wx - x0, base + ty, wz - z0, 5, true)

func put(x, y, z, id, overwrite):
	if x < 0 or x >= SIZE or z < 0 or z >= SIZE or y < 0 or y >= HEIGHT:
		return
	var i = index(x, y, z)
	if overwrite or blocks[i] == 0:
		blocks[i] = id
		top = maxi(top, y)

func face_tile(id, f):
	var t = BLOCK_TILES[id]
	if f == 0:
		return t[0]
	if f == 1:
		return t[1]
	return t[2]

func tile_uvs(tile):
	var e = 0.002   # tiny inset so neighboring tiles don't bleed in
	var s = 1.0 / TILES_PER_ROW
	var u = (tile % TILES_PER_ROW) * s
	var v = floori(tile / float(TILES_PER_ROW)) * s
	return [Vector2(u + e, v + e), Vector2(u + s - e, v + e), Vector2(u + s - e, v + s - e), Vector2(u + e, v + s - e)]

# Block next to this chunk. Chunks that aren't loaded count as air.
func neighbor_block(x, y, z):
	if y < 0:
		return 1
	if y >= HEIGHT:
		return 0
	if x >= 0 and x < SIZE and z >= 0 and z < SIZE:
		return blocks[index(x, y, z)]
	return world.get_block(cx * SIZE + x, y, cz * SIZE + z)

func build_mesh():
	# Remove the old collision so rebuilds don't stack copies
	for child in get_children():
		if child is StaticBody3D:
			remove_child(child)
			child.queue_free()

	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_material(world.material)

	for x in SIZE:
		for z in SIZE:
			for y in range(top + 1):
				var id = blocks[index(x, y, z)]
				if id == 0:
					continue
				# Vertex alpha marks ores so the X-Ray shader can keep them solid
				var ore_flag = 1.0 if (id >= 9 and id <= 13) else 0.0
				for f in FACES.size():
					var face = FACES[f]
					var d = face["dir"]
					# Skip faces that touch another block (they can't be seen)
					if neighbor_block(x + d.x, y + d.y, z + d.z) != 0:
						continue
					var uvs = tile_uvs(face_tile(id, f))
					var normal = Vector3(d)
					var origin = Vector3(x, y, z)
					var v = face["verts"]
					for i in [0, 1, 2, 0, 2, 3]:
						st.set_color(Color(1, 1, 1, ore_flag))
						st.set_normal(normal)
						st.set_uv(uvs[i])
						st.add_vertex(origin + v[i])

	mesh = st.commit()
	create_trimesh_collision()
