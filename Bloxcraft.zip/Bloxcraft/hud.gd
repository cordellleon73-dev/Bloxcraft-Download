extends CanvasLayer

const Items = preload("res://items.gd")

const TILE = 128
const COLUMNS = 9
const ARMOR_START = 36
const OFFHAND = 40
# Atlas tile used as the icon for each block ID
const BLOCK_ICON_TILES = {1: 3, 2: 2, 3: 1, 4: 4, 5: 5, 6: 7, 7: 8, 8: 9, 9: 10, 10: 11, 11: 12, 12: 13, 13: 14}
const ARMOR_SLOT_NAMES = ["Helmet", "Chestplate", "Leggings", "Boots"]

var atlas = preload("res://atlas.png")
var items_atlas = preload("res://items.png")
var ui_atlas = preload("res://ui.png")
var icons = {}
var ui_icons = {}
var style_normal = StyleBoxFlat.new()
var style_selected = StyleBoxFlat.new()
var hotbar_ui = []
var offhand_hotbar_ui
var inv_ui = {}
var creative_ui = {}
var craft_buttons = []
var health_icons = []
var hunger_icons = []
var armor_icons = []
var armor_row
var armor_label
var status_center
var hotbar_box
var inventory_screen
var creative_screen
var death_screen
var damage_overlay
var held_icon
var held_label
var mine_bar

@onready var player = get_node("../Player")

func _ready():
	style_normal.bg_color = Color(0, 0, 0, 0.5)
	style_normal.set_border_width_all(3)
	style_normal.border_color = Color(0.3, 0.3, 0.3)
	style_selected.bg_color = Color(0, 0, 0, 0.5)
	style_selected.set_border_width_all(5)
	style_selected.border_color = Color.WHITE

	# Red flash when you take damage
	damage_overlay = ColorRect.new()
	damage_overlay.color = Color(1, 0, 0, 0)
	damage_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(damage_overlay)
	damage_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Crosshair
	var cross_box = CenterContainer.new()
	add_child(cross_box)
	cross_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cross_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var cross = Label.new()
	cross.text = "+"
	cross.add_theme_font_size_override("font_size", 32)
	cross_box.add_child(cross)

	# Mining progress bar (sits just under the crosshair)
	mine_bar = ProgressBar.new()
	mine_bar.custom_minimum_size = Vector2(120, 10)
	mine_bar.max_value = 1.0
	mine_bar.show_percentage = false
	mine_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mine_bar.visible = false
	add_child(mine_bar)

	# Bottom area: status bars above the hotbar
	var bottom = VBoxContainer.new()
	add_child(bottom)
	bottom.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var spacer = Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(spacer)

	status_center = CenterContainer.new()
	status_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(status_center)
	var status = HBoxContainer.new()
	status.custom_minimum_size = Vector2(9 * 68 + 80, 0)
	status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_center.add_child(status)
	var indent = Control.new()
	indent.custom_minimum_size = Vector2(80, 0)
	indent.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.add_child(indent)
	var left_col = VBoxContainer.new()
	left_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.add_child(left_col)
	armor_row = make_icon_row(armor_icons)
	left_col.add_child(armor_row)
	left_col.add_child(make_icon_row(health_icons))
	var right_col = VBoxContainer.new()
	right_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.add_child(right_col)
	var right_pad = Control.new()
	right_pad.custom_minimum_size = Vector2(0, 26)
	right_pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right_col.add_child(right_pad)
	right_col.add_child(make_icon_row(hunger_icons))

	# Hotbar: offhand slot on the left, then the nine slots
	hotbar_box = CenterContainer.new()
	hotbar_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(hotbar_box)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	hotbar_box.add_child(row)
	offhand_hotbar_ui = make_slot()
	offhand_hotbar_ui["panel"].tooltip_text = "Offhand (X swaps)"
	row.add_child(offhand_hotbar_ui["panel"])
	var off_gap = Control.new()
	off_gap.custom_minimum_size = Vector2(12, 0)
	off_gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(off_gap)
	for i in 9:
		var ui = make_slot()
		row.add_child(ui["panel"])
		hotbar_ui.append(ui)
	var pad = Control.new()
	pad.custom_minimum_size = Vector2(0, 16)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(pad)

	# Survival inventory screen (hidden until you press E): slots on the left, crafting on the right
	inventory_screen = CenterContainer.new()
	add_child(inventory_screen)
	inventory_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	inventory_screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inventory_screen.visible = false
	var panel = PanelContainer.new()
	inventory_screen.add_child(panel)
	var split = HBoxContainer.new()
	split.add_theme_constant_override("separation", 24)
	panel.add_child(split)

	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	split.add_child(box)
	var title = Label.new()
	title.text = "Inventory"
	title.add_theme_font_size_override("font_size", 24)
	box.add_child(title)
	build_equipment_row(box, inv_ui, false)
	var main_grid = make_grid()
	box.add_child(main_grid)
	for i in range(9, 36):
		var ui = make_slot(_on_slot_input.bind(i))
		main_grid.add_child(ui["panel"])
		inv_ui[i] = ui
	var gap = Control.new()
	gap.custom_minimum_size = Vector2(0, 8)
	box.add_child(gap)
	var hotbar_grid = make_grid()
	box.add_child(hotbar_grid)
	for i in range(0, 9):
		var ui = make_slot(_on_slot_input.bind(i))
		hotbar_grid.add_child(ui["panel"])
		inv_ui[i] = ui

	var craft_box = VBoxContainer.new()
	craft_box.add_theme_constant_override("separation", 8)
	split.add_child(craft_box)
	var craft_title = Label.new()
	craft_title.text = "Crafting"
	craft_title.add_theme_font_size_override("font_size", 24)
	craft_box.add_child(craft_title)
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(440, 440)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	craft_box.add_child(scroll)
	var craft_list = VBoxContainer.new()
	craft_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(craft_list)
	for i in player.recipes.size():
		var b = make_recipe_button(i)
		craft_list.add_child(b)
		craft_buttons.append(b)

	# Creative inventory screen: every block and item, plus your hotbar and equipment
	creative_screen = CenterContainer.new()
	add_child(creative_screen)
	creative_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	creative_screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	creative_screen.visible = false
	var cpanel = PanelContainer.new()
	creative_screen.add_child(cpanel)
	var cbox = VBoxContainer.new()
	cbox.add_theme_constant_override("separation", 8)
	cpanel.add_child(cbox)
	var ctitle = Label.new()
	ctitle.text = "Creative Inventory"
	ctitle.add_theme_font_size_override("font_size", 24)
	cbox.add_child(ctitle)
	var hint = Label.new()
	hint.text = "Click a slot below to choose it, then click an item. Right-click a slot to clear it."
	cbox.add_child(hint)
	var cscroll = ScrollContainer.new()
	cscroll.custom_minimum_size = Vector2(COLUMNS * 68 + 12, 4 * 68)
	cscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	cbox.add_child(cscroll)
	var palette = make_grid()
	cscroll.add_child(palette)
	for id in all_items():
		var ui = make_slot(_on_palette_input.bind(id))
		ui["icon"].texture = get_icon(id)
		ui["panel"].tooltip_text = Items.item_name(id)
		palette.add_child(ui["panel"])
	var cgap = Control.new()
	cgap.custom_minimum_size = Vector2(0, 8)
	cbox.add_child(cgap)
	build_equipment_row(cbox, creative_ui, true)
	var chotbar = make_grid()
	cbox.add_child(chotbar)
	for i in range(0, 9):
		var ui = make_slot(_on_creative_slot_input.bind(i))
		chotbar.add_child(ui["panel"])
		creative_ui[i] = ui

	# The stack you're carrying with the mouse (survival)
	held_icon = TextureRect.new()
	held_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	held_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	held_icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	held_icon.custom_minimum_size = Vector2(48, 48)
	held_icon.size = Vector2(48, 48)
	held_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	held_icon.visible = false
	add_child(held_icon)
	held_label = Label.new()
	held_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	held_label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	held_label.add_theme_font_size_override("font_size", 20)
	held_label.add_theme_color_override("font_outline_color", Color.BLACK)
	held_label.add_theme_constant_override("outline_size", 6)
	held_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	held_icon.add_child(held_label)
	held_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Death screen
	death_screen = ColorRect.new()
	death_screen.color = Color(0.35, 0, 0, 0.65)
	death_screen.visible = false
	add_child(death_screen)
	death_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dcenter = CenterContainer.new()
	death_screen.add_child(dcenter)
	dcenter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dbox = VBoxContainer.new()
	dbox.add_theme_constant_override("separation", 20)
	dcenter.add_child(dbox)
	var dlabel = Label.new()
	dlabel.text = "You Died!"
	dlabel.add_theme_font_size_override("font_size", 64)
	dlabel.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dbox.add_child(dlabel)
	var respawn_button = Button.new()
	respawn_button.text = "Respawn"
	respawn_button.custom_minimum_size = Vector2(300, 56)
	respawn_button.add_theme_font_size_override("font_size", 24)
	respawn_button.pressed.connect(_on_respawn_pressed)
	dbox.add_child(respawn_button)

	refresh.call_deferred()

# Row of 10 status icons (hearts, drumsticks or armor)
func make_icon_row(list):
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 0)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in 10:
		var t = TextureRect.new()
		t.custom_minimum_size = Vector2(26, 26)
		t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		t.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		t.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(t)
		list.append(t)
	return row

# Armor slots and the offhand slot, shown above the main inventory
func build_equipment_row(parent, ui_dict, creative_mode):
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	parent.add_child(row)
	var armor_title = Label.new()
	armor_title.text = "Armor"
	armor_title.add_theme_font_size_override("font_size", 18)
	row.add_child(armor_title)
	for i in range(ARMOR_START, ARMOR_START + 4):
		var cb = _on_creative_slot_input.bind(i) if creative_mode else _on_slot_input.bind(i)
		var ui = make_slot(cb)
		ui["panel"].tooltip_text = ARMOR_SLOT_NAMES[i - ARMOR_START]
		row.add_child(ui["panel"])
		ui_dict[i] = ui
	var gap = Control.new()
	gap.custom_minimum_size = Vector2(20, 0)
	row.add_child(gap)
	var off_title = Label.new()
	off_title.text = "Offhand"
	off_title.add_theme_font_size_override("font_size", 18)
	row.add_child(off_title)
	var off_cb = _on_creative_slot_input.bind(OFFHAND) if creative_mode else _on_slot_input.bind(OFFHAND)
	var off_ui = make_slot(off_cb)
	row.add_child(off_ui["panel"])
	ui_dict[OFFHAND] = off_ui
	if not creative_mode:
		armor_label = Label.new()
		armor_label.add_theme_font_size_override("font_size", 18)
		row.add_child(armor_label)

# Every block and item, for the creative palette
func all_items():
	var list = []
	for id in range(1, 14):
		list.append(id)
	for id in range(100, 107):
		list.append(id)
	for t in 6:
		for k in 4:
			list.append(200 + t * 10 + k)
	for t in 4:
		for k in 4:
			list.append(300 + t * 10 + k)
	return list

# Icon for any block or item ID, cut from the atlas images
func get_icon(id):
	if icons.has(id):
		return icons[id]
	var tex = AtlasTexture.new()
	if id < 100:
		var t = BLOCK_ICON_TILES.get(id, 3)
		tex.atlas = atlas
		tex.region = Rect2((t % 4) * TILE, floori(t / 4.0) * TILE, TILE, TILE)
	else:
		var t = Items.icon_index(id)
		tex.atlas = items_atlas
		tex.region = Rect2((t % 8) * TILE, floori(t / 8.0) * TILE, TILE, TILE)
	icons[id] = tex
	return tex

# Heart, drumstick or armor icon: row 0/1/2, column 0 full, 1 half, 2 empty
func ui_icon(row, col):
	var key = row * 3 + col
	if ui_icons.has(key):
		return ui_icons[key]
	var tex = AtlasTexture.new()
	tex.atlas = ui_atlas
	tex.region = Rect2(col * 64, row * 64, 64, 64)
	ui_icons[key] = tex
	return tex

func make_recipe_button(i):
	var r = player.recipes[i]
	var b = Button.new()
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.icon = get_icon(r["out"])
	b.expand_icon = true
	b.add_theme_constant_override("icon_max_width", 36)
	b.add_theme_font_size_override("font_size", 16)
	b.focus_mode = Control.FOCUS_NONE
	var needs = []
	for id in r["in"]:
		needs.append(str(r["in"][id]) + " " + Items.item_name(id))
	var count_text = ""
	if r["count"] > 1:
		count_text = " x" + str(r["count"])
	b.text = " " + Items.item_name(r["out"]) + count_text + "  (" + ", ".join(needs) + ")"
	b.pressed.connect(_on_recipe_pressed.bind(i))
	return b

func _on_recipe_pressed(i):
	player.craft(i)

func _on_respawn_pressed():
	player.respawn()

func make_grid():
	var grid = GridContainer.new()
	grid.columns = COLUMNS
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	return grid

# Pass a Callable to make the slot clickable. With no argument it just displays.
func make_slot(callback = Callable()):
	var panel = Panel.new()
	panel.custom_minimum_size = Vector2(64, 64)
	panel.add_theme_stylebox_override("panel", style_normal)
	var icon = TextureRect.new()
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(icon)
	icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 8)
	var label = Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	label.add_theme_font_size_override("font_size", 20)
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 6)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(label)
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 4)
	# Durability bar (only shown on damaged tools and armor)
	var dur = ProgressBar.new()
	dur.custom_minimum_size = Vector2(0, 4)
	dur.max_value = 1.0
	dur.show_percentage = false
	dur.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dur.visible = false
	var fill = StyleBoxFlat.new()
	fill.bg_color = Color.GREEN
	var back = StyleBoxFlat.new()
	back.bg_color = Color(0, 0, 0, 0.8)
	dur.add_theme_stylebox_override("fill", fill)
	dur.add_theme_stylebox_override("background", back)
	panel.add_child(dur)
	dur.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE, Control.PRESET_MODE_MINSIZE, 6)
	if callback.is_valid():
		panel.gui_input.connect(callback)
	else:
		panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return {"panel": panel, "icon": icon, "label": label, "dur": dur, "fill": fill}

func _on_slot_input(event, i):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		player.click_slot(i)

func _on_palette_input(event, id):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		player.pick_creative(id)

func _on_creative_slot_input(event, i):
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT or event.button_index == MOUSE_BUTTON_RIGHT:
			player.click_creative_slot(i, event.button_index)

func _process(_delta):
	if held_icon.visible:
		held_icon.position = get_viewport().get_mouse_position() - Vector2(24, 24)
	mine_bar.visible = player.mine_ratio > 0.0
	mine_bar.value = player.mine_ratio
	mine_bar.position = get_viewport().get_visible_rect().size / 2 + Vector2(-60, 26)

func flash_damage():
	damage_overlay.color.a = 0.35
	var tween = create_tween()
	tween.tween_property(damage_overlay, "color:a", 0.0, 0.4)

func update_slot(ui, item):
	if item == null:
		ui["icon"].texture = null
		ui["label"].text = ""
		ui["dur"].visible = false
	else:
		ui["icon"].texture = get_icon(item[0])
		ui["label"].text = str(item[1]) if item[1] > 1 else ""
		ui["panel"].tooltip_text = Items.item_name(item[0])
		var max_d = Items.max_durability(item[0])
		if item.size() > 2 and max_d > 0 and item[2] < max_d:
			var ratio = clampf(float(item[2]) / max_d, 0.0, 1.0)
			ui["dur"].visible = true
			ui["dur"].value = ratio
			ui["fill"].bg_color = Color.from_hsv(ratio * 0.33, 1.0, 0.9)
		else:
			ui["dur"].visible = false

func set_border(ui, selected):
	ui["panel"].add_theme_stylebox_override("panel", style_selected if selected else style_normal)

# Hearts, drumsticks and armor icons. Each icon is worth 2 points.
func set_icons(icon_list, row, value):
	for i in icon_list.size():
		var v = value - i * 2
		var col = 2
		if v >= 2:
			col = 0
		elif v > 0:
			col = 1
		icon_list[i].texture = ui_icon(row, col)

func refresh_status():
	status_center.visible = not player.creative and not player.inventory_open
	set_icons(health_icons, 0, player.health)
	set_icons(hunger_icons, 1, player.hunger)
	var points = player.armor_points()
	armor_row.visible = points > 0
	set_icons(armor_icons, 2, points)
	death_screen.visible = player.dead

func refresh():
	var creative = player.creative
	hotbar_box.visible = not player.inventory_open
	inventory_screen.visible = player.inventory_open and not creative
	creative_screen.visible = player.inventory_open and creative
	for i in hotbar_ui.size():
		update_slot(hotbar_ui[i], player.inventory[i])
		set_border(hotbar_ui[i], i == player.selected_slot)
	update_slot(offhand_hotbar_ui, player.offhand)
	for i in inv_ui:
		update_slot(inv_ui[i], player.get_slot(i))
		set_border(inv_ui[i], i == player.selected_slot)
	for i in creative_ui:
		update_slot(creative_ui[i], player.get_slot(i))
		set_border(creative_ui[i], i == player.creative_target)
	for i in craft_buttons.size():
		craft_buttons[i].disabled = not player.can_craft(player.recipes[i])
	armor_label.text = "  Armor: " + str(player.armor_points())
	var held = player.held
	held_icon.visible = held != null and player.inventory_open and not creative
	if held != null:
		held_icon.texture = get_icon(held[0])
		held_label.text = str(held[1]) if held[1] > 1 else ""
	refresh_status()
