extends RefCounted
# Shared item data: names, tiers, durability, food, mining rules and crafting recipes.

# ---- Blocks (IDs below 100) ----
# 1 stone, 2 dirt, 3 grass, 4 planks, 5 log, 6 andesite, 7 bedrock, 8 leaves,
# 9 copper ore, 10 iron ore, 11 gold ore, 12 diamond ore, 13 emerald ore
const BLOCK_NAMES = {
	1: "Stone", 2: "Dirt", 3: "Grass", 4: "Planks", 5: "Log", 6: "Andesite", 7: "Bedrock", 8: "Leaves",
	9: "Copper Ore", 10: "Iron Ore", 11: "Gold Ore", 12: "Diamond Ore", 13: "Emerald Ore",
}

# ---- Materials and food ----
const STICK = 100
const APPLE = 106
const MATERIAL_NAMES = {
	100: "Stick", 101: "Copper Ingot", 102: "Iron Ingot", 103: "Gold Ingot", 104: "Diamond", 105: "Emerald",
	106: "Apple",
}
# Food: item ID -> hunger points restored
const FOOD = {106: 4}

# ---- Tools: ID = 200 + tier * 10 + type ----
const TIER_NAMES = ["Wooden", "Stone", "Copper", "Iron", "Golden", "Diamond"]
const TOOL_NAMES = ["Pickaxe", "Axe", "Shovel", "Sword"]
const TIER_MATERIAL = [4, 1, 101, 102, 103, 104]      # what each tier is made from
const TIER_MINING = [0, 1, 1, 2, 0, 3]                # best ore tier a pickaxe of that tier can collect
const TIER_SPEED = [2.0, 4.0, 5.0, 6.0, 12.0, 8.0]    # mining speed
const TIER_DURABILITY = [59, 131, 190, 250, 32, 1561] # blocks a tool can break
const TOOL_COST = [3, 3, 1, 2]                        # material per pickaxe, axe, shovel, sword
const TOOL_STICKS = [2, 2, 2, 1]

# ---- Armor: ID = 300 + tier * 10 + type (no emerald armor) ----
const ARMOR_TIER_NAMES = ["Copper", "Iron", "Golden", "Diamond"]
const ARMOR_NAMES = ["Helmet", "Chestplate", "Leggings", "Boots"]
const ARMOR_MATERIAL = [101, 102, 103, 104]
const ARMOR_COST = [5, 8, 7, 4]
const ARMOR_COLORS = [Color(0.80, 0.47, 0.31), Color(0.85, 0.85, 0.87), Color(0.98, 0.84, 0.27), Color(0.36, 0.89, 0.88)]
const ARMOR_BASE_DURABILITY = [11, 16, 15, 13]        # helmet, chestplate, leggings, boots
const ARMOR_DURABILITY_MULT = [12, 15, 7, 33]         # per armor tier
# Armor points per tier: [helmet, chestplate, leggings, boots]
const ARMOR_POINTS = [[2, 5, 4, 1], [2, 6, 5, 2], [2, 5, 3, 1], [3, 8, 6, 3]]

# ---- Mining rules ----
# Seconds to break by hand
const HARDNESS = {
	1: 5.0, 2: 0.8, 3: 0.9, 4: 3.0, 5: 3.0, 6: 5.0, 8: 0.3,
	9: 6.0, 10: 7.0, 11: 7.0, 12: 9.0, 13: 9.0,
}
# Which tool type is fast on a block: 0 pickaxe, 1 axe, 2 shovel, 3 sword
const BEST_TOOL = {1: 0, 2: 2, 3: 2, 4: 1, 5: 1, 6: 0, 8: 3, 9: 0, 10: 0, 11: 0, 12: 0, 13: 0}
# Ore block: [item it drops, minimum pickaxe tier]
const ORES = {9: [101, 1], 10: [102, 1], 11: [103, 2], 12: [104, 2], 13: [105, 2]}

static func is_tool_item(id):
	return id >= 200 and id < 260

static func is_armor_item(id):
	return id >= 300 and id < 340

static func is_food(id):
	return FOOD.has(id)

static func tool_tier(id):
	return floori((id - 200) / 10.0)

static func tool_type(id):
	return (id - 200) % 10

static func armor_tier(id):
	return floori((id - 300) / 10.0)

static func armor_type(id):
	return (id - 300) % 10

static func armor_points(id):
	return ARMOR_POINTS[armor_tier(id)][armor_type(id)]

# How many uses a tool or armor piece has (0 for everything else)
static func max_durability(id):
	if id >= 200 and id < 260:
		return TIER_DURABILITY[tool_tier(id)]
	if id >= 300 and id < 340:
		return ARMOR_BASE_DURABILITY[armor_type(id)] * ARMOR_DURABILITY_MULT[armor_tier(id)]
	return 0

# A new stack: [id, count], or [id, count, durability_left] for tools and armor
static func new_stack(id, count = 1):
	var d = max_durability(id)
	if d > 0:
		return [id, count, d]
	return [id, count]

static func item_name(id):
	if id < 100:
		return BLOCK_NAMES.get(id, "Block")
	if id < 200:
		return MATERIAL_NAMES.get(id, "Item")
	if id >= 200 and id < 260:
		return TIER_NAMES[tool_tier(id)] + " " + TOOL_NAMES[tool_type(id)]
	if id >= 300 and id < 340:
		return ARMOR_TIER_NAMES[armor_tier(id)] + " " + ARMOR_NAMES[armor_type(id)]
	return "Item"

static func max_stack(id):
	return 1 if id >= 200 else 64

# What breaking a block gives you. pickaxe_tier is -1 when you aren't holding a pickaxe.
static func drop_for(block_id, pickaxe_tier):
	if ORES.has(block_id):
		var ore = ORES[block_id]
		if pickaxe_tier >= ore[1]:
			return ore[0]
		return 0
	return block_id

# Position of an item's icon in items.png (8 icons per row)
static func icon_index(id):
	if id >= 100 and id < 200:
		return id - 100
	if id >= 200 and id < 260:
		return (1 + tool_tier(id)) * 8 + tool_type(id)
	if id >= 300 and id < 340:
		return (3 + armor_tier(id)) * 8 + 4 + armor_type(id)
	return 0

static func build_recipes():
	var r = []
	r.append({"out": 4, "count": 4, "in": {5: 1}})        # 1 log -> 4 planks
	r.append({"out": STICK, "count": 4, "in": {4: 2}})    # 2 planks -> 4 sticks
	for t in 6:
		for k in 4:
			r.append({"out": 200 + t * 10 + k, "count": 1,
				"in": {TIER_MATERIAL[t]: TOOL_COST[k], STICK: TOOL_STICKS[k]}})
	for t in 4:
		for k in 4:
			r.append({"out": 300 + t * 10 + k, "count": 1,
				"in": {ARMOR_MATERIAL[t]: ARMOR_COST[k]}})
	return r
