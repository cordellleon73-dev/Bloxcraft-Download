extends Control

const GAME_SCENE = "res://main.tscn"   # change this if your game scene has a different name
const Saves = preload("res://saves.gd")
const SettingsPanel = preload("res://settings_panel.gd")

var column
var menu_box
var worlds_box
var world_list
var create_box
var settings_panel
var name_edit
var seed_edit
var mode_button
var create_creative = false
var confirm
var pending_delete = ""

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var bg = ColorRect.new()
	bg.color = Color(0.1, 0.12, 0.16)
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center = CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	column = VBoxContainer.new()
	column.add_theme_constant_override("separation", 24)
	center.add_child(column)

	var title = Label.new()
	title.text = "My Minecraft"
	title.add_theme_font_size_override("font_size", 64)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(title)

	build_main_menu()
	build_worlds_box()
	build_create_box()

	settings_panel = SettingsPanel.new()
	settings_panel.back_pressed.connect(_on_back_to_menu)
	column.add_child(settings_panel)

	confirm = ConfirmationDialog.new()
	confirm.title = "Delete World"
	confirm.confirmed.connect(_on_delete_confirmed)
	add_child(confirm)

	show_screen(menu_box)

func show_screen(target):
	for screen in [menu_box, worlds_box, create_box, settings_panel]:
		screen.visible = (screen == target)

func add_button(parent, text, callback):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(360, 56)
	b.add_theme_font_size_override("font_size", 24)
	if callback.is_valid():
		b.pressed.connect(callback)
	parent.add_child(b)
	return b

func make_label(text, size = 20):
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	return l

# ---------- Main menu ----------

func build_main_menu():
	menu_box = VBoxContainer.new()
	menu_box.add_theme_constant_override("separation", 12)
	column.add_child(menu_box)
	add_button(menu_box, "Singleplayer", _on_singleplayer)
	var multi = add_button(menu_box, "Multiplayer", Callable())
	multi.disabled = true
	multi.tooltip_text = "Coming soon"
	add_button(menu_box, "Settings", _on_settings)
	add_button(menu_box, "Exit", _on_exit)

func _on_singleplayer():
	refresh_world_list()
	show_screen(worlds_box)

func _on_settings():
	show_screen(settings_panel)

func _on_back_to_menu():
	show_screen(menu_box)

func _on_exit():
	get_tree().quit()

# ---------- World list ----------

func build_worlds_box():
	worlds_box = VBoxContainer.new()
	worlds_box.add_theme_constant_override("separation", 12)
	column.add_child(worlds_box)
	var heading = make_label("Select World", 32)
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	worlds_box.add_child(heading)
	var scroll = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(620, 300)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	worlds_box.add_child(scroll)
	world_list = VBoxContainer.new()
	world_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	world_list.add_theme_constant_override("separation", 8)
	scroll.add_child(world_list)
	add_button(worlds_box, "Create New World", _on_create_screen)
	add_button(worlds_box, "Back", _on_back_to_menu)

func format_time(ts):
	if int(ts) == 0:
		return "never played"
	var bias = Time.get_time_zone_from_system()["bias"]
	return Time.get_datetime_string_from_unix_time(int(ts) + int(bias) * 60).replace("T", " ")

func refresh_world_list():
	for child in world_list.get_children():
		child.queue_free()
	var worlds = Saves.list_worlds()
	if worlds.is_empty():
		var empty = make_label("No worlds yet. Create one!", 22)
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		world_list.add_child(empty)
	for w in worlds:
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		world_list.add_child(row)
		var play = Button.new()
		play.custom_minimum_size = Vector2(500, 64)
		play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		play.alignment = HORIZONTAL_ALIGNMENT_LEFT
		play.add_theme_font_size_override("font_size", 20)
		var mode = "Creative" if w["creative"] else "Survival"
		play.text = str(w["name"]) + "\n" + mode + "  |  Seed " + str(w["seed"]) + "  |  " + format_time(w["last_played"])
		play.pressed.connect(_on_play_world.bind(w["id"]))
		row.add_child(play)
		var del = Button.new()
		del.text = "Delete"
		del.custom_minimum_size = Vector2(90, 64)
		del.add_theme_font_size_override("font_size", 18)
		del.pressed.connect(_on_delete_world.bind(w["id"], str(w["name"])))
		row.add_child(del)

func _on_play_world(id):
	Saves.current_id = id
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_delete_world(id, world_name):
	pending_delete = id
	confirm.dialog_text = "Delete \"" + world_name + "\" forever?\nThis can't be undone."
	confirm.popup_centered()

func _on_delete_confirmed():
	if pending_delete != "":
		Saves.delete_world(pending_delete)
		pending_delete = ""
		refresh_world_list()

# ---------- Create world ----------

func build_create_box():
	create_box = VBoxContainer.new()
	create_box.add_theme_constant_override("separation", 12)
	column.add_child(create_box)
	var heading = make_label("Create New World", 32)
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	create_box.add_child(heading)

	create_box.add_child(make_label("World name"))
	name_edit = LineEdit.new()
	name_edit.custom_minimum_size = Vector2(420, 48)
	name_edit.add_theme_font_size_override("font_size", 22)
	create_box.add_child(name_edit)

	create_box.add_child(make_label("Seed (blank = random)"))
	seed_edit = LineEdit.new()
	seed_edit.placeholder_text = "Number or any text"
	seed_edit.custom_minimum_size = Vector2(420, 48)
	seed_edit.add_theme_font_size_override("font_size", 22)
	create_box.add_child(seed_edit)

	mode_button = add_button(create_box, "Game Mode: Survival", _on_create_mode)
	add_button(create_box, "Create World", _on_create_world)
	add_button(create_box, "Back", _on_back_to_worlds)

func _on_create_screen():
	name_edit.text = "New World"
	seed_edit.text = ""
	create_creative = false
	update_mode_text()
	show_screen(create_box)

func update_mode_text():
	mode_button.text = "Game Mode: " + ("Creative" if create_creative else "Survival")

func _on_create_mode():
	create_creative = not create_creative
	update_mode_text()

func _on_back_to_worlds():
	show_screen(worlds_box)

func _on_create_world():
	var id = Saves.create_world(name_edit.text, seed_edit.text, create_creative)
	Saves.current_id = id
	get_tree().change_scene_to_file(GAME_SCENE)
