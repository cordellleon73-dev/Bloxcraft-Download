extends CanvasLayer

const MENU_SCENE = "res://menu.tscn"
const SettingsPanel = preload("res://settings_panel.gd")

var menu_box
var settings_panel
var mode_button
var info_label

@onready var player = get_node("../Player")
@onready var world = get_node("../World")
@onready var admin = get_node("../Admin")

func _ready():
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS   # keep working while the game is paused
	visible = false

	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center = CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	menu_box = VBoxContainer.new()
	menu_box.add_theme_constant_override("separation", 12)
	center.add_child(menu_box)

	var title = Label.new()
	title.text = "Paused"
	title.add_theme_font_size_override("font_size", 48)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu_box.add_child(title)

	info_label = Label.new()
	info_label.add_theme_font_size_override("font_size", 20)
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	menu_box.add_child(info_label)

	add_button(menu_box, "Resume", resume)
	mode_button = add_button(menu_box, "", _on_mode_pressed)
	add_button(menu_box, "Settings", _on_settings)
	add_button(menu_box, "Admin Panel (Beta)", _on_admin)
	add_button(menu_box, "Save and Quit to Title", _on_main_menu)

	settings_panel = SettingsPanel.new()
	settings_panel.visible = false
	settings_panel.back_pressed.connect(show_menu)
	settings_panel.changed.connect(_on_settings_changed)
	center.add_child(settings_panel)

	update_mode_text()

func add_button(parent, text, callback):
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(360, 56)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func _unhandled_input(event):
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		# The admin panel handles its own Escape, and you can't pause while dead
		if admin.visible or player.dead:
			return
		if visible:
			if settings_panel.visible:
				show_menu()
			else:
				resume()
		elif player.inventory_open:
			player.set_inventory(false)
		else:
			open_pause()
		get_viewport().set_input_as_handled()

func show_menu():
	menu_box.visible = true
	settings_panel.visible = false

func open_pause():
	world.save_all()
	info_label.text = world.world_name + "   |   Seed: " + str(world.world_seed)
	update_mode_text()
	show_menu()
	visible = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func resume():
	visible = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func update_mode_text():
	mode_button.text = "Game Mode: " + ("Creative" if player.creative else "Survival")

func _on_mode_pressed():
	player.set_creative(not player.creative)
	update_mode_text()

func _on_settings():
	menu_box.visible = false
	settings_panel.visible = true

func _on_admin():
	visible = false
	admin.open_panel()

# Apply changed settings to the running game
func _on_settings_changed():
	player.load_settings()
	world.apply_settings()

func _on_main_menu():
	world.save_all()
	get_tree().paused = false
	get_tree().change_scene_to_file(MENU_SCENE)
