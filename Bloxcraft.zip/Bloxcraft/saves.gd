extends RefCounted
# Helpers for world saves. Each world lives in user://worlds/<id>/

const ROOT = "user://worlds"

static var current_id = ""   # the world being played

static func world_dir(id):
	return ROOT + "/" + id

static func chunk_dir(id):
	return world_dir(id) + "/chunks"

static func info_path(id):
	return world_dir(id) + "/world.cfg"

static func chunk_path(id, key):
	return chunk_dir(id) + "/" + str(key.x) + "_" + str(key.y) + ".dat"

# Blank = random seed. A number is used as is. Any other text is turned into a number.
static func seed_from_text(text):
	text = text.strip_edges()
	if text == "":
		randomize()
		return randi() % 2000000000
	if text.is_valid_int():
		return posmod(int(text), 2000000000)
	return posmod(hash(text), 2000000000)

static func create_world(world_name, seed_text, creative):
	randomize()
	DirAccess.make_dir_recursive_absolute(ROOT)
	var id = "w" + str(int(Time.get_unix_time_from_system())) + "_" + str(randi() % 10000)
	DirAccess.make_dir_recursive_absolute(chunk_dir(id))
	var clean_name = world_name.strip_edges()
	if clean_name == "":
		clean_name = "New World"
	var now = int(Time.get_unix_time_from_system())
	var cfg = ConfigFile.new()
	cfg.set_value("world", "name", clean_name)
	cfg.set_value("world", "seed", seed_from_text(seed_text))
	cfg.set_value("world", "creative", creative)
	cfg.set_value("world", "created", now)
	cfg.set_value("world", "last_played", now)
	cfg.save(info_path(id))
	return id

# Newest played first
static func list_worlds():
	var worlds = []
	var dir = DirAccess.open(ROOT)
	if dir == null:
		return worlds
	for folder in dir.get_directories():
		var cfg = ConfigFile.new()
		if cfg.load(info_path(folder)) != OK:
			continue
		worlds.append({
			"id": folder,
			"name": cfg.get_value("world", "name", folder),
			"seed": cfg.get_value("world", "seed", 0),
			"creative": cfg.get_value("world", "creative", false),
			"last_played": cfg.get_value("world", "last_played", 0),
		})
	worlds.sort_custom(func(a, b): return a["last_played"] > b["last_played"])
	return worlds

static func delete_world(id):
	remove_recursive(world_dir(id))

static func remove_recursive(path):
	var dir = DirAccess.open(path)
	if dir == null:
		return
	for f in dir.get_files():
		DirAccess.remove_absolute(path + "/" + f)
	for d in dir.get_directories():
		remove_recursive(path + "/" + d)
	DirAccess.remove_absolute(path)

# If you run the game scene directly (F6) with no world chosen, use a test world
static func ensure_current():
	if current_id != "" and FileAccess.file_exists(info_path(current_id)):
		return
	var found = ""
	for w in list_worlds():
		if w["name"] == "Test World":
			found = w["id"]
			break
	if found == "":
		found = create_world("Test World", "", false)
	current_id = found

static func write_chunk(id, key, blocks, top):
	DirAccess.make_dir_recursive_absolute(chunk_dir(id))
	var f = FileAccess.open(chunk_path(id, key), FileAccess.WRITE)
	if f == null:
		return
	f.store_var({"blocks": blocks, "top": top})
	f.close()

static func read_chunk(id, key):
	var path = chunk_path(id, key)
	if not FileAccess.file_exists(path):
		return null
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null:
		return null
	var data = f.get_var()
	f.close()
	if data is Dictionary and data.has("blocks") and data.has("top"):
		return data
	return null
