extends VBoxContainer
# The settings screen. Used by both the main menu and the pause menu.

signal back_pressed
signal changed

const SETTINGS_PATH = "user://settings.cfg"

var fullscreen_check
var sens_slider
var sens_label
var render_slider
var render_label

func _ready():
	add_theme_constant_override("separation", 12)

	fullscreen_check = CheckButton.new()
	fullscreen_check.text = "Fullscreen"
	fullscreen_check.add_theme_font_size_override("font_size", 22)
	fullscreen_check.toggled.connect(_on_changed)
	add_child(fullscreen_check)

	sens_label = Label.new()
	sens_label.add_theme_font_size_override("font_size", 22)
	add_child(sens_label)
	sens_slider = make_slider(1, 10)
	add_child(sens_slider)

	render_label = Label.new()
	render_label.add_theme_font_size_override("font_size", 22)
	add_child(render_label)
	render_slider = make_slider(2, 6)
	add_child(render_slider)

	var back = Button.new()
	back.text = "Back"
	back.custom_minimum_size = Vector2(360, 56)
	back.add_theme_font_size_override("font_size", 24)
	back.pressed.connect(func(): back_pressed.emit())
	add_child(back)

	load_values()

func make_slider(min_v, max_v):
	var s = HSlider.new()
	s.min_value = min_v
	s.max_value = max_v
	s.step = 1
	s.custom_minimum_size = Vector2(360, 24)
	s.value_changed.connect(_on_changed)
	return s

func load_values():
	var cfg = ConfigFile.new()
	cfg.load(SETTINGS_PATH)   # fine if it doesn't exist yet, the defaults below are used
	fullscreen_check.set_pressed_no_signal(cfg.get_value("settings", "fullscreen", false))
	sens_slider.set_value_no_signal(round(cfg.get_value("settings", "sensitivity", 0.003) / 0.001))
	render_slider.set_value_no_signal(cfg.get_value("settings", "render_distance", 3))
	apply_fullscreen()
	update_labels()

func update_labels():
	sens_label.text = "Mouse sensitivity: " + str(int(sens_slider.value))
	render_label.text = "Render distance: " + str(int(render_slider.value)) + " chunks (higher = slower)"

func apply_fullscreen():
	if fullscreen_check.button_pressed:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func save_values():
	var cfg = ConfigFile.new()
	cfg.load(SETTINGS_PATH)   # keep any other saved values
	cfg.set_value("settings", "fullscreen", fullscreen_check.button_pressed)
	cfg.set_value("settings", "sensitivity", sens_slider.value * 0.001)
	cfg.set_value("settings", "render_distance", int(render_slider.value))
	cfg.save(SETTINGS_PATH)

func _on_changed(_value):
	apply_fullscreen()
	update_labels()
	save_values()
	changed.emit()
