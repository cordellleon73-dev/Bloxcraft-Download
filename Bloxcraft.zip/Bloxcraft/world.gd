extends Node3D

const Saves = preload("res://saves.gd")

const SIZE = 16
const HEIGHT = 64
const BASE_HEIGHT = 22
const AMPLITUDE = 16.0        # how tall the hills are
const CAVE_THRESHOLD = 0.5    # lower = more caves
const TREE_CHANCE = 0.012     # chance per grass block
const AUTOSAVE_SECONDS = 30.0

var render_distance = 3       # set by the Settings menu
var world_seed = 0            # stored in the world's save
var world_name = ""
var xray = false              # toggled from the Admin panel

var ChunkScript = preload("res://chunk.gd")
var atlas = preload("res://atlas.png")

var chunks = {}   # Vector2i -> chunk node
var queue = []
var last_center = Vector2i(1000000, 1000000)
var autosave_timer = 0.0
var material = StandardMaterial3D.new()
var xray_material = ShaderMaterial.new()
var height_noise = FastNoiseLite.new()
var cave_noise = FastNoiseLite.new()

@onready var player = get_node("../Player")

func _ready():
	Saves.ensure_current()
	var cfg = ConfigFile.new()
	cfg.load(Saves.info_path(Saves.current_id))
	world_name = cfg.get_value("world", "name", "World")
	world_seed = int(cfg.get_value("world", "seed", 0))
	apply_settings()
	height_noise.seed = world_seed
	height_noise.frequency = 0.012
	height_noise.fractal_octaves = 4
	cave_noise.seed = world_seed + 1
	cave_noise.frequency = 0.06
	cave_noise.fractal_type = FastNoiseLite.FRACTAL_NONE
	material.albedo_texture = atlas
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS

	# X-Ray: everything is nearly see-through except ores (marked by vertex alpha)
	var shader = Shader.new()
	shader.code = """
shader_type spatial;
render_mode depth_draw_never, cull_back;
uniform sampler2D albedo_tex : source_color, filter_nearest_mipmap;
void fragment() {
	ALBEDO = texture(albedo_tex, UV).rgb;
	ROUGHNESS = 1.0;
	if (COLOR.a < 0.5) {
		ALPHA = 0.12;
	} else {
		ALPHA = 1.0;
	}
}
"""
	xray_material.shader = shader
	xray_material.set_shader_parameter("albedo_tex", atlas)

	DirAccess.make_dir_recursive_absolute(Saves.chunk_dir(Saves.current_id))

func apply_settings():
	var cfg = ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		render_distance = cfg.get_value("settings", "render_distance", 3)
	last_center = Vector2i(1000000, 1000000)   # forces the chunk list to update

func set_xray(value):
	xray = value
	for key in chunks:
		chunks[key].apply_xray()

func _process(delta):
	var center = chunk_of(player.global_position)
	if center != last_center:
		last_center = center
		update_chunks(center)
	# Load one chunk per frame so the game doesn't freeze
	if queue.size() > 0:
		var key = queue.pop_front()
		if not chunks.has(key):
			load_chunk(key)
	autosave_timer += delta
	if autosave_timer >= AUTOSAVE_SECONDS:
		autosave_timer = 0.0
		save_all()

# ---------- Saving ----------

func save_all():
	for key in chunks:
		var c = chunks[key]
		if c.dirty:
			Saves.write_chunk(Saves.current_id, key, c.blocks, c.top)
			c.dirty = false
	player.save_player()

func _notification(what):
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_all()

# Used by chunks: returns the saved data for an edited chunk, or null
func take_saved(key):
	return Saves.read_chunk(Saves.current_id, key)

# ---------- Loading chunks ----------

func chunk_of(pos):
	return Vector2i(floori(pos.x / float(SIZE)), floori(pos.z / float(SIZE)))

func is_loaded_at(pos):
	return chunks.has(chunk_of(pos))

func update_chunks(center):
	for key in chunks.keys():
		if abs(key.x - center.x) > render_distance + 1 or abs(key.y - center.y) > render_distance + 1:
			unload_chunk(key)
	var wanted = []
	for dx in range(-render_distance, render_distance + 1):
		for dz in range(-render_distance, render_distance + 1):
			var key = Vector2i(center.x + dx, center.y + dz)
			if not chunks.has(key):
				wanted.append(key)
	# Nearest chunks first
	wanted.sort_custom(func(a, b): return (a - center).length_squared() < (b - center).length_squared())
	queue = wanted

func load_chunk(key):
	var c = MeshInstance3D.new()
	c.set_script(ChunkScript)
	c.world = self
	c.cx = key.x
	c.cz = key.y
	c.position = Vector3(key.x * SIZE, 0, key.y * SIZE)
	chunks[key] = c
	add_child(c)

func unload_chunk(key):
	var c = chunks[key]
	if c.dirty:
		Saves.write_chunk(Saves.current_id, key, c.blocks, c.top)
	c.queue_free()
	chunks.erase(key)

# ---------- Reading and editing blocks anywhere in the world ----------

func get_block(wx, y, wz):
	if y < 0 or y >= HEIGHT:
		return 0
	var key = Vector2i(floori(wx / float(SIZE)), floori(wz / float(SIZE)))
	var c = chunks.get(key)
	if c == null:
		return 0
	return c.get_block(wx - key.x * SIZE, y, wz - key.y * SIZE)

func set_block(wx, y, wz, id):
	if y < 0 or y >= HEIGHT:
		return
	var key = Vector2i(floori(wx / float(SIZE)), floori(wz / float(SIZE)))
	var c = chunks.get(key)
	if c == null:
		return
	var lx = wx - key.x * SIZE
	var lz = wz - key.y * SIZE
	c.set_block(lx, y, lz, id)
	# If the edit touches a chunk border, the neighbor's mesh needs updating too
	if lx == 0:
		rebuild(key + Vector2i(-1, 0))
	if lx == SIZE - 1:
		rebuild(key + Vector2i(1, 0))
	if lz == 0:
		rebuild(key + Vector2i(0, -1))
	if lz == SIZE - 1:
		rebuild(key + Vector2i(0, 1))

func rebuild(key):
	var c = chunks.get(key)
	if c != null:
		c.build_mesh()

# ---------- World generation (used by the chunks) ----------

func terrain_height(wx, wz):
	return clampi(BASE_HEIGHT + int(round(height_noise.get_noise_2d(wx, wz) * AMPLITUDE)), 3, HEIGHT - 12)

func terrain_block(wx, y, wz, h):
	if y == 0:
		return 7   # bedrock
	if y > h:
		return 0
	if y > 2 and cave_noise.get_noise_3d(wx, y, wz) > CAVE_THRESHOLD:
		return 0   # cave
	if y == h:
		return 3   # grass
	if y >= h - 3:
		return 2   # dirt
	return ore_at(wx, y, wz)

# Repeatable "random" numbers from 0 to 1. They depend on the seed.
func rand2(wx, wz, salt = 0):
	var v = sin(wx * 12.9898 + wz * 78.233 + salt * 37.719 + (world_seed % 10007) * 0.7311) * 43758.5453
	return v - floor(v)

func rand3(a, b, c, salt = 0):
	var v = sin(a * 12.9898 + b * 78.233 + c * 37.719 + salt * 11.135 + (world_seed % 10007) * 0.7311) * 43758.5453
	return v - floor(v)

# Stone, or an ore if this spot is part of a vein
func ore_at(wx, y, wz):
	# Emerald: rare single blocks
	if y <= 30 and rand3(wx, y, wz, 5) < 0.0003:
		return 13
	# Other ores come in clumps inside 4x4x4 cells
	var r = rand3(floori(wx / 4.0), floori(y / 4.0), floori(wz / 4.0), 0)
	var ore = 0
	if r < 0.012:
		if y <= 14:
			ore = 12   # diamond
	elif r < 0.05:
		if y <= 24:
			ore = 11   # gold
	elif r < 0.12:
		if y <= 36:
			ore = 10   # iron
	elif r < 0.21:
		if y <= 42:
			ore = 9    # copper
	if ore != 0 and rand3(wx, y, wz, ore) < 0.16:
		return ore
	return 1

func is_tree_origin(wx, wz):
	if rand2(wx, wz) >= TREE_CHANCE:
		return false
	var h = terrain_height(wx, wz)
	return terrain_block(wx, h, wz, h) == 3

func tree_height(wx, wz):
	return 4 + int(rand2(wx, wz, 1) * 3)
